#!/bin/bash
# 模型服务器安装脚本（仅使用 uv）

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "=========================================="
echo "模型API服务器安装脚本"
echo "=========================================="

if ! command -v uv &> /dev/null; then
    echo "错误: 未找到 uv，请先安装: curl -LsSf https://astral.sh/uv/install.sh | sh"
    exit 1
fi

if [ ! -f "/opt/venv/models/bin/activate" ]; then
    echo "错误: 未找到 Python 虚拟环境 /opt/venv/models/bin/activate"
    echo "请先运行: ./scripts/07_models_setup.sh"
    exit 1
fi

if [ ! -f "requirements.txt" ]; then
    echo "错误: 未找到 requirements.txt，请确保在 server 目录中运行"
    exit 1
fi

echo ""
echo "1. 使用 uv 安装依赖..."
source /opt/venv/models/bin/activate
uv pip install -r requirements.txt

echo ""
echo "2. 创建日志目录..."
mkdir -p /data/logs

echo ""
echo "3. 配置环境变量..."
if [ ! -f ".env" ]; then
    if [ -f ".env.example" ]; then
        cp .env.example .env
        echo "已创建 .env，请编辑: vim .env（API_KEYS、模型路径等）"
    fi
else
    echo ".env 已存在，跳过"
fi

chmod +x start.sh 2>/dev/null || true

echo ""
echo "=========================================="
echo "安装完成"
echo "=========================================="
echo "下一步: 编辑 .env 后执行 ./start.sh"
echo "文档: README.md"
echo ""
