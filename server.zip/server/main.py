"""
模型API服务器 - FastAPI实现
支持多模型、流式输出、OpenAI兼容API、ASR/TTS
"""
import os
import tempfile
import time
import json
import logging
import uuid
from typing import List, Optional, Dict, Any, AsyncGenerator
from contextlib import asynccontextmanager

from fastapi import FastAPI, File, Form, HTTPException, Depends, Header, Request, UploadFile
from fastapi.responses import StreamingResponse, JSONResponse, Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import uvicorn

from server.model_manager import ModelManager
from server.config import Settings, get_settings

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/data/logs/model_server.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# 全局模型管理器
model_manager: Optional[ModelManager] = None


def verify_api_key(
    authorization: Optional[str] = Header(None),
    settings: Settings = Depends(get_settings)
) -> str:
    """验证API密钥"""
    if not settings.api_keys:
        # 如果没有配置API密钥，允许所有请求（仅用于开发）
        return "anonymous"
    
    if not authorization:
        raise HTTPException(status_code=401, detail="缺少Authorization头")
    
    try:
        scheme, token = authorization.split()
        if scheme.lower() != "bearer":
            raise HTTPException(status_code=401, detail="认证方案必须是Bearer")
        if token not in settings.api_keys:
            raise HTTPException(status_code=403, detail="无效的API密钥")
        return token
    except ValueError:
        raise HTTPException(status_code=401, detail="Authorization头格式错误")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用生命周期管理"""
    global model_manager
    
    settings = get_settings()
    logger.info("正在初始化模型管理器...")
    
    try:
        model_manager = ModelManager(settings)
        await model_manager.initialize()
        logger.info("模型管理器初始化成功")
    except Exception as e:
        logger.error(f"模型管理器初始化失败: {e}", exc_info=True)
        raise
    
    yield
    
    # 关闭时清理
    logger.info("正在关闭服务...")
    if model_manager:
        await model_manager.cleanup()
    logger.info("服务已关闭")


# 创建FastAPI应用
def create_app() -> FastAPI:
    """创建FastAPI应用"""
    settings = get_settings()
    
    app = FastAPI(
        title="模型API服务器",
        description="基于Qwen3模型的API服务，支持多模型、流式输出",
        version="1.0.0",
        lifespan=lifespan
    )
    
    # 配置CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    return app


app = create_app()


# 请求/响应模型
class ChatMessage(BaseModel):
    role: str = Field(..., description="消息角色: user, assistant, system")
    content: str = Field(..., description="消息内容")


class ChatRequest(BaseModel):
    model: str = Field(..., description="模型名称")
    messages: List[ChatMessage] = Field(..., description="对话消息列表")
    temperature: Optional[float] = Field(default=0.7, ge=0.0, le=2.0)
    max_tokens: Optional[int] = Field(default=2048, ge=1, le=32768)
    stream: Optional[bool] = Field(default=False, description="是否流式输出")
    top_p: Optional[float] = Field(default=0.9, ge=0.0, le=1.0)
    top_k: Optional[int] = Field(default=50, ge=1, le=100)
    frequency_penalty: Optional[float] = Field(default=0.0, ge=-2.0, le=2.0)
    presence_penalty: Optional[float] = Field(default=0.0, ge=-2.0, le=2.0)
    stop: Optional[List[str]] = Field(default=None, description="停止序列")


class EmbeddingRequest(BaseModel):
    model: str = Field(..., description="模型名称")
    input: str | List[str] = Field(..., description="输入文本或文本列表")
    encoding_format: Optional[str] = Field(default="float", description="编码格式")


class EmbeddingResponse(BaseModel):
    object: str = "list"
    data: List[Dict[str, Any]]
    model: str
    usage: Dict[str, int]


@app.get("/")
async def root():
    """根路径"""
    return {
        "status": "running",
        "service": "model-api-server",
        "version": "1.0.0"
    }


@app.get("/health")
async def health():
    """健康检查端点"""
    if model_manager is None:
        return JSONResponse(
            status_code=503,
            content={"status": "unhealthy", "reason": "模型管理器未初始化"}
        )
    
    models_status = await model_manager.get_models_status()
    return {
        "status": "healthy",
        "models": models_status
    }


@app.get("/v1/models")
async def list_models(
    api_key: str = Depends(verify_api_key),
    settings: Settings = Depends(get_settings)
):
    """列出可用模型"""
    if model_manager is None:
        raise HTTPException(status_code=503, detail="模型管理器未初始化")
    
    models = await model_manager.list_models()
    
    return {
        "object": "list",
        "data": [
            {
                "id": model_id,
                "object": "model",
                "created": int(time.time()),
                "owned_by": "qwen"
            }
            for model_id in models
        ]
    }


@app.post("/v1/chat/completions")
async def chat_completions(
    request: ChatRequest,
    api_key: str = Depends(verify_api_key)
):
    """Chat Completions API（OpenAI兼容）"""
    if model_manager is None:
        raise HTTPException(status_code=503, detail="模型管理器未初始化")
    
    try:
        # 检查模型是否存在
        if not await model_manager.has_model(request.model):
            raise HTTPException(
                status_code=404,
                detail=f"模型 '{request.model}' 不存在或未加载"
            )
        
        # 构建消息
        messages = [{"role": msg.role, "content": msg.content} for msg in request.messages]
        
        if request.stream:
            # 流式生成
            return StreamingResponse(
                stream_chat_completion(
                    request.model,
                    messages,
                    request.temperature,
                    request.max_tokens,
                    request.top_p,
                    request.top_k,
                    request.frequency_penalty,
                    request.presence_penalty,
                    request.stop
                ),
                media_type="text/event-stream"
            )
        else:
            # 非流式生成
            result = await model_manager.generate(
                model_id=request.model,
                messages=messages,
                temperature=request.temperature,
                max_tokens=request.max_tokens,
                top_p=request.top_p,
                top_k=request.top_k,
                frequency_penalty=request.frequency_penalty,
                presence_penalty=request.presence_penalty,
                stop=request.stop
            )
            
            # 构建响应
            response = {
                "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
                "object": "chat.completion",
                "created": int(time.time()),
                "model": request.model,
                "choices": [{
                    "index": 0,
                    "message": {
                        "role": "assistant",
                        "content": result["content"]
                    },
                    "finish_reason": result.get("finish_reason", "stop")
                }],
                "usage": result.get("usage", {
                    "prompt_tokens": 0,
                    "completion_tokens": 0,
                    "total_tokens": 0
                })
            }
            
            return response
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"生成错误: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"生成失败: {str(e)}")


async def stream_chat_completion(
    model_id: str,
    messages: List[Dict[str, str]],
    temperature: float,
    max_tokens: int,
    top_p: float,
    top_k: int,
    frequency_penalty: float,
    presence_penalty: float,
    stop: Optional[List[str]]
) -> AsyncGenerator[str, None]:
    """流式生成器"""
    chat_id = f"chatcmpl-{uuid.uuid4().hex[:8]}"
    created = int(time.time())
    
    try:
        async for chunk in model_manager.generate_stream(
            model_id=model_id,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            top_p=top_p,
            top_k=top_k,
            frequency_penalty=frequency_penalty,
            presence_penalty=presence_penalty,
            stop=stop
        ):
            # SSE格式输出
            chunk_data = {
                "id": chat_id,
                "object": "chat.completion.chunk",
                "created": created,
                "model": model_id,
                "choices": [{
                    "index": 0,
                    "delta": {"content": chunk.get("content", "")},
                    "finish_reason": chunk.get("finish_reason")
                }]
            }
            yield f"data: {json.dumps(chunk_data, ensure_ascii=False)}\n\n"
        
        # 发送结束标记
        yield "data: [DONE]\n\n"
        
    except Exception as e:
        logger.error(f"流式生成错误: {e}", exc_info=True)
        error_data = {
            "error": {
                "message": str(e),
                "type": "server_error"
            }
        }
        yield f"data: {json.dumps(error_data, ensure_ascii=False)}\n\n"


@app.post("/v1/embeddings")
async def embeddings(
    request: EmbeddingRequest,
    api_key: str = Depends(verify_api_key)
):
    """Embeddings API（OpenAI兼容）"""
    if model_manager is None:
        raise HTTPException(status_code=503, detail="模型管理器未初始化")
    
    try:
        # 检查模型是否存在
        if not await model_manager.has_model(request.model):
            raise HTTPException(
                status_code=404,
                detail=f"模型 '{request.model}' 不存在或未加载"
            )
        
        # 处理输入
        inputs = request.input if isinstance(request.input, list) else [request.input]
        
        # 生成嵌入向量
        embeddings_result = await model_manager.generate_embeddings(
            model_id=request.model,
            texts=inputs
        )
        
        # 构建响应
        response = EmbeddingResponse(
            data=[
                {
                    "object": "embedding",
                    "embedding": emb.tolist() if hasattr(emb, 'tolist') else emb,
                    "index": idx
                }
                for idx, emb in enumerate(embeddings_result["embeddings"])
            ],
            model=request.model,
            usage={
                "prompt_tokens": embeddings_result.get("prompt_tokens", 0),
                "total_tokens": embeddings_result.get("total_tokens", 0)
            }
        )
        
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"嵌入生成错误: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"嵌入生成失败: {str(e)}")


@app.post("/v1/audio/transcriptions")
async def audio_transcriptions(
    file: UploadFile = File(..., description="音频文件（wav/mp3 等）"),
    model: str = Form(..., description="模型名称，如 qwen3-asr"),
    language: Optional[str] = Form(default=None, description="可选，强制语言如 Chinese/English"),
    api_key: str = Depends(verify_api_key),
):
    """语音识别（OpenAI 兼容）。上传音频文件，返回识别文本。"""
    if model_manager is None:
        raise HTTPException(status_code=503, detail="模型管理器未初始化")
    if not await model_manager.has_model(model):
        raise HTTPException(status_code=404, detail=f"模型 '{model}' 不存在或未加载")
    try:
        suffix = os.path.splitext(file.filename or "")[1] or ".wav"
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            content = await file.read()
            tmp.write(content)
            tmp_path = tmp.name
        try:
            result = await model_manager.transcribe(
                model_id=model,
                audio=tmp_path,
                language=language,
            )
            return {"text": result["text"], "language": result.get("language")}
        finally:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"语音识别错误: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"语音识别失败: {str(e)}")


class SpeechRequest(BaseModel):
    model: str = Field(..., description="模型名称，如 qwen3-tts")
    input: str = Field(..., description="要合成的文本")
    voice: Optional[str] = Field(default="Vivian", description="音色，如 Vivian/Ryan")
    language: Optional[str] = Field(default="Chinese", description="语言")
    instruct: Optional[str] = Field(default="", description="自然语言指令，如 用愤怒的语气")


@app.post("/v1/audio/speech")
async def audio_speech(
    request: SpeechRequest,
    api_key: str = Depends(verify_api_key),
):
    """文本转语音（OpenAI 兼容）。返回 WAV 音频流。"""
    if model_manager is None:
        raise HTTPException(status_code=503, detail="模型管理器未初始化")
    if not await model_manager.has_model(request.model):
        raise HTTPException(status_code=404, detail=f"模型 '{request.model}' 不存在或未加载")
    try:
        wav_bytes, sample_rate = await model_manager.tts_generate(
            model_id=request.model,
            text=request.input,
            language=request.language or "Chinese",
            speaker=request.voice or "Vivian",
            instruct=request.instruct or "",
        )
        return Response(
            content=wav_bytes,
            media_type="audio/wav",
            headers={"Content-Disposition": "attachment; filename=speech.wav"},
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"语音合成错误: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"语音合成失败: {str(e)}")


@app.post("/generate")
async def generate_simple(
    text: str,
    model: str = "qwen3-a3b",
    max_tokens: int = 2048,
    temperature: float = 0.7,
    api_key: str = Depends(verify_api_key)
):
    """简单生成接口（兼容旧版本）"""
    if model_manager is None:
        raise HTTPException(status_code=503, detail="模型管理器未初始化")
    
    try:
        messages = [{"role": "user", "content": text}]
        result = await model_manager.generate(
            model_id=model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens
        )
        
        return {"result": result["content"]}
        
    except Exception as e:
        logger.error(f"生成错误: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    settings = get_settings()
    uvicorn.run(
        "server.main:app",
        host=settings.host,
        port=settings.port,
        workers=1,  # 模型服务通常使用单worker
        log_level=settings.log_level.lower(),
        reload=False
    )
