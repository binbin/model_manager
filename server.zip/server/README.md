# 模型 API 服务器

基于 FastAPI 的模型 API 服务器，支持多模型、流式输出、OpenAI 兼容 API。

## 功能特性

- ✅ **多模型支持**：同时加载和管理多个模型（Qwen3-A3B、Qwen3-VL、BGE 等）
- ✅ **流式输出**：支持 Server-Sent Events (SSE)流式响应
- ✅ **OpenAI 兼容 API**：完全兼容 OpenAI Chat Completions 和 Embeddings API
- ✅ **API 密钥认证**：支持 Bearer Token 认证
- ✅ **异步处理**：基于 FastAPI 异步框架，高并发支持
- ✅ **健康检查**：提供健康检查端点
- ✅ **日志记录**：完整的日志记录和错误处理
- ✅ **uv 包管理**：使用 uv 安装依赖（需先安装 uv）
- ✅ **ASR/TTS**：支持 Qwen3-ASR 语音识别、Qwen3-TTS 文本转语音（需启用并安装 qwen-asr/qwen-tts）

## 依赖说明

- **server 仅声明 API 层依赖**（FastAPI、uvicorn、pydantic 等）。**模型运行时依赖**（torch、transformers、sentence-transformers、CANN/TBE 等）由部署环境提供。
- 在本项目内部署时，请先按项目根目录文档完成环境准备（如 `scripts/07_models_setup.sh`），再在**同一虚拟环境**中安装 server 依赖并启动服务。

## 快速开始

### 部署方案选择

**方案 A：项目内部署**（推荐用于开发/测试）

- 代码位置：项目根目录下的 `server/` 目录
- 优点：便于开发、版本控制统一
- 适用：开发环境、测试环境

**方案 B：独立部署到/opt**（推荐用于生产）

- 代码位置：`/opt/model_server/server/`
- 优点：符合 Linux FHS 标准、独立管理
- 适用：生产环境

> 📖 详细部署说明请参考 [DEPLOYMENT.md](DEPLOYMENT.md)

### 方式 1：使用自动部署脚本（推荐）

```bash
# 部署到/opt/model_server（生产环境）
sudo ./server/deploy.sh /opt/model_server

# 或部署到当前目录（开发环境）
./server/deploy.sh .
```

### 方式 2：手动部署

#### 方案 A：项目内部署

```bash
# 1. 进入server目录
cd server

# 2. 安装依赖
./install.sh

# 3. 配置环境
cp .env.example .env
vim .env

# 4. 启动服务
./start.sh
```

#### 方案 B：部署到/opt/model_server

```bash
# 1. 创建部署目录并复制文件
sudo mkdir -p /opt/model_server
sudo cp -r server /opt/model_server/
cd /opt/model_server/server

# 2. 安装依赖（需已安装 uv: curl -LsSf https://astral.sh/uv/install.sh | sh）
./install.sh

# 3. 配置环境
cp .env.example .env
vim .env

# 4. 配置systemd服务（需要修改服务文件中的路径）
sudo cp model-server.service /etc/systemd/system/
sudo vim /etc/systemd/system/model-server.service
sudo systemctl daemon-reload
sudo systemctl start model-server
```

## API 使用

### 1. 健康检查

```bash
curl http://localhost:8000/health
```

### 2. 列出可用模型

```bash
curl -X GET http://localhost:8000/v1/models \
  -H "Authorization: Bearer your-secret-api-key-here"
```

### 3. Chat Completions API

**非流式**：

```bash
curl -X POST http://localhost:8000/v1/chat/completions \
  -H "Authorization: Bearer your-secret-api-key-here" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "qwen3-a3b",
    "messages": [
      {"role": "user", "content": "你好，请介绍一下自己。"}
    ],
    "temperature": 0.7,
    "max_tokens": 2048
  }'
```

**流式输出**：

```bash
curl -X POST http://localhost:8000/v1/chat/completions \
  -H "Authorization: Bearer your-secret-api-key-here" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "qwen3-a3b",
    "messages": [
      {"role": "user", "content": "写一首关于春天的诗"}
    ],
    "stream": true
  }' \
  --no-buffer
```

### 4. Embeddings API

```bash
curl -X POST http://localhost:8000/v1/embeddings \
  -H "Authorization: Bearer your-secret-api-key-here" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "bge-large-zh-v1.5",
    "input": "这是一个测试文本"
  }'
```

### 5. 语音识别 (ASR) 与 文本转语音 (TTS)

需在 `.env` 中启用 `QWEN3_ASR_ENABLED=true` / `QWEN3_TTS_ENABLED=true`，并确保已安装 qwen-asr、qwen-tts 及 soundfile。

**语音识别**（上传音频，返回文本）：

```bash
curl -X POST http://localhost:8000/v1/audio/transcriptions \
  -H "Authorization: Bearer your-secret-api-key-here" \
  -F "file=@/path/to/audio.wav" \
  -F "model=qwen3-asr" \
  -F "language=Chinese"
```

**文本转语音**（JSON 请求，返回 WAV 文件）：

```bash
curl -X POST http://localhost:8000/v1/audio/speech \
  -H "Authorization: Bearer your-secret-api-key-here" \
  -H "Content-Type: application/json" \
  -d '{"model": "qwen3-tts", "input": "你好，这是一段测试。", "voice": "Vivian", "language": "Chinese"}' \
  --output speech.wav
```

### 6. Python 客户端示例

```python
import requests

url = "http://localhost:8000/v1/chat/completions"
headers = {
    "Authorization": "Bearer your-secret-api-key-here",
    "Content-Type": "application/json"
}
data = {
    "model": "qwen3-a3b",
    "messages": [
        {"role": "user", "content": "你好"}
    ],
    "temperature": 0.7,
    "max_tokens": 2048
}

response = requests.post(url, json=data, headers=headers)
print(response.json())
```

**流式请求**：

```python
import requests
import json

url = "http://localhost:8000/v1/chat/completions"
headers = {
    "Authorization": "Bearer your-secret-api-key-here",
    "Content-Type": "application/json"
}
data = {
    "model": "qwen3-a3b",
    "messages": [
        {"role": "user", "content": "写一首诗"}
    ],
    "stream": True
}

response = requests.post(url, json=data, headers=headers, stream=True)

for line in response.iter_lines():
    if line:
        line_str = line.decode('utf-8')
        if line_str.startswith('data: '):
            data_str = line_str[6:]  # 移除 'data: ' 前缀
            if data_str == '[DONE]':
                break
            try:
                chunk = json.loads(data_str)
                if 'choices' in chunk and len(chunk['choices']) > 0:
                    delta = chunk['choices'][0].get('delta', {})
                    content = delta.get('content', '')
                    if content:
                        print(content, end='', flush=True)
            except json.JSONDecodeError:
                pass
print()  # 换行
```

## 配置说明

### 环境变量

在 `.env` 文件中配置：

- `HOST`: 服务监听地址（默认：0.0.0.0）
- `PORT`: 服务端口（默认：8000）
- `LOG_LEVEL`: 日志级别（默认：INFO）
- `API_KEYS`: API 密钥，多个用逗号分隔（留空则不需要认证）
- `CORS_ORIGINS`: CORS 允许的源，多个用逗号分隔（\*表示允许所有）
- `QWEN3_A3B_PATH`: Qwen3-A3B 模型路径
- `QWEN3_VL_PATH`: Qwen3-VL 模型路径
- `BGE_PATH`: BGE 嵌入模型路径
- `QWEN3_VL_ENABLED`: 是否启用 Qwen3-VL 模型（true/false）
- `BGE_ENABLED`: 是否启用 BGE 模型（true/false）

### 模型配置

服务器会自动检测配置的模型路径，如果模型存在且启用，则会在启动时加载。

## 依赖管理（uv）

本服务仅使用 **uv** 安装依赖。

**安装 uv**：`curl -LsSf https://astral.sh/uv/install.sh | sh`

**安装项目依赖**：`./install.sh`，或手动激活 venv 后 `uv pip install -r requirements.txt`

常用命令：`uv pip list`、`uv pip freeze`

## 目录结构

```
server/
├── __init__.py          # 包初始化
├── main.py              # 主应用
├── model_manager.py     # 模型管理
├── config.py            # 配置
├── pyproject.toml       # 项目配置
├── requirements.txt     # 依赖列表（uv 安装）
├── .python-version      # Python 版本
├── .env.example         # 环境变量示例
├── start.sh             # 启动
├── install.sh           # 安装依赖（uv）
├── deploy.sh            # 部署
├── test_api.sh          # API 测试
├── model-server.service # systemd 服务
├── DEPLOYMENT.md        # 部署说明
└── README.md            # 本文档
```

## 故障排查

### 服务无法启动

1. 检查 Python 环境：

   ```bash
   source /opt/venv/models/bin/activate
   python --version
   ```

2. 检查依赖是否安装：

   ```bash
   uv pip list | grep fastapi
   ```

3. 检查模型路径：

   ```bash
   ls -lh /data/models/qwen3-a3b/
   ```

4. 查看日志：
   ```bash
   tail -f /data/logs/model_server.log
   sudo journalctl -u model-server -n 100
   ```

### 模型加载失败

1. 检查模型文件是否完整
2. 检查 NPU 状态：`npu-smi info`
3. 检查内存是否充足：`free -h`
4. 查看详细错误日志

### API 请求失败

1. 检查 API 密钥是否正确
2. 检查服务是否运行：`curl http://localhost:8000/health`
3. 检查请求格式是否正确
4. 查看服务日志

## 性能优化

1. **使用量化模型**：减少内存占用
2. **调整并发数**：根据 NPU 数量调整
3. **使用流式输出**：减少等待时间
4. **批处理请求**：提高吞吐量

## 安全建议

1. **配置 API 密钥**：生产环境必须配置
2. **使用 HTTPS**：通过 Nginx 配置 SSL
3. **限制 CORS**：不要使用 `*`，指定具体域名
4. **配置防火墙**：只开放必要端口
5. **定期更新**：保持依赖包最新

## 许可证

本项目遵循项目主许可证。
