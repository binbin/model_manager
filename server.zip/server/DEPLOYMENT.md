# 部署目录方案

## 目录选择分析

### 方案 A：项目内部署（推荐用于开发/测试）

**路径**: `/path/to/deploy/server/`

**优点**:

- ✅ 代码和配置统一管理，便于版本控制
- ✅ 开发调试方便
- ✅ 与项目其他脚本在同一目录结构

**缺点**:

- ❌ 如果项目目录是临时目录，不适合生产环境
- ❌ 不符合 Linux FHS 标准

**适用场景**: 开发环境、测试环境、项目本身就是部署目录

### 方案 B：/opt/model_server（推荐用于生产）

**路径**: `/opt/model_server/`

**优点**:

- ✅ 符合 Linux FHS 标准（/opt 用于可选软件包）
- ✅ 独立于项目目录，便于管理
- ✅ 生产环境标准做法
- ✅ 便于多版本管理

**缺点**:

- ❌ 需要额外的部署步骤
- ❌ 代码更新需要同步

**适用场景**: 生产环境、正式部署

### 方案 C：/usr/local/model_server

**路径**: `/usr/local/model_server/`

**优点**:

- ✅ 符合 Linux FHS 标准
- ✅ 系统级应用标准位置

**缺点**:

- ❌ 通常用于系统级工具，不太适合应用服务

## 推荐方案

**开发/测试环境**: 使用方案 A，直接在项目目录中运行
**生产环境**: 使用方案 B，部署到 `/opt/model_server`

## 部署步骤

### 方案 A：项目内部署

```bash
# 1. 确保在项目根目录
cd /path/to/deploy

# 2. 安装依赖（需已安装 uv: curl -LsSf https://astral.sh/uv/install.sh | sh）
cd server
./install.sh

# 3. 配置环境
cp .env.example .env
vim .env

# 4. 启动服务
./start.sh

# 或使用systemd（需要修改服务文件中的路径）
```

### 方案 B：部署到/opt/model_server

```bash
# 1. 创建部署目录
sudo mkdir -p /opt/model_server
sudo chown $USER:$USER /opt/model_server

# 2. 复制server目录
cp -r /path/to/deploy/server /opt/model_server/

# 3. 进入部署目录
cd /opt/model_server

# 4. 安装依赖（需已安装 uv: curl -LsSf https://astral.sh/uv/install.sh | sh）
./server/install.sh

# 5. 配置环境
cp server/.env.example server/.env
vim server/.env

# 6. 配置systemd服务
sudo cp server/model-server.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl start model-server
```

## 路径配置说明

### 当前配置

- **代码位置**: `server/` 目录（项目根目录下）
- **systemd 服务**: 配置为 `/opt/model_server`（需要根据实际部署调整）
- **启动脚本**: 自动检测当前目录

### 需要调整的地方

1. **systemd 服务文件**: 根据实际部署路径修改 `WorkingDirectory` 和 `ExecStart`
2. **启动脚本**: 已支持自动检测，但需要确保 Python 路径正确
3. **日志路径**: 统一使用 `/data/logs`（不依赖部署位置）

## 快速部署脚本

使用 `deploy.sh` 脚本可以自动部署到指定位置：

```bash
# 部署到/opt/model_server
./server/deploy.sh /opt/model_server

# 部署到当前目录（项目内）
./server/deploy.sh .
```
