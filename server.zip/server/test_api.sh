#!/bin/bash
# API测试脚本

set -e

# 配置
API_URL="${API_URL:-http://localhost:8000}"
API_KEY="${API_KEY:-your-secret-api-key-here}"

echo "=========================================="
echo "模型API服务器测试"
echo "API URL: $API_URL"
echo "=========================================="
echo ""

# 1. 健康检查
echo "1. 健康检查..."
curl -s "$API_URL/health" | python3 -m json.tool || echo "失败"
echo ""

# 2. 列出模型
echo "2. 列出可用模型..."
curl -s -X GET "$API_URL/v1/models" \
  -H "Authorization: Bearer $API_KEY" | python3 -m json.tool || echo "失败"
echo ""

# 3. Chat Completions（非流式）
echo "3. Chat Completions（非流式）..."
curl -s -X POST "$API_URL/v1/chat/completions" \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "qwen3-a3b",
    "messages": [
      {"role": "user", "content": "你好，请用一句话介绍自己。"}
    ],
    "temperature": 0.7,
    "max_tokens": 100
  }' | python3 -m json.tool || echo "失败"
echo ""

# 4. Chat Completions（流式）
echo "4. Chat Completions（流式）..."
echo "---"
curl -s -X POST "$API_URL/v1/chat/completions" \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "qwen3-a3b",
    "messages": [
      {"role": "user", "content": "请说：你好"}
    ],
    "stream": true,
    "max_tokens": 50
  }' --no-buffer | grep -E "^data: " | head -5 || echo "失败"
echo "---"
echo ""

# 5. Embeddings（如果BGE模型已启用）
echo "5. Embeddings API..."
curl -s -X POST "$API_URL/v1/embeddings" \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "bge-large-zh-v1.5",
    "input": "这是一个测试文本"
  }' | python3 -m json.tool 2>/dev/null || echo "BGE模型未启用或不存在"
echo ""

echo "=========================================="
echo "测试完成"
echo "=========================================="
