#!/bin/bash
# 模型服务器部署脚本

set -e

# 获取脚本所在目录（server目录）
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

# 默认部署路径
DEFAULT_DEPLOY_PATH="/opt/model_server"

# 解析参数
DEPLOY_PATH="${1:-$DEFAULT_DEPLOY_PATH}"
DEPLOY_PATH=$(realpath -m "$DEPLOY_PATH")

echo "=========================================="
echo "模型API服务器部署脚本"
echo "=========================================="
echo "项目目录: $PROJECT_ROOT"
echo "部署路径: $DEPLOY_PATH"
echo ""

# 检查是否为root用户（如果需要创建/opt目录）
if [[ "$DEPLOY_PATH" == /opt/* ]] && [[ $EUID -ne 0 ]]; then
    echo "警告: 部署到 /opt 目录需要root权限"
    echo "请使用 sudo 运行此脚本，或选择其他目录"
    read -p "是否继续？(y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# 创建部署目录
echo "1. 创建部署目录..."
mkdir -p "$DEPLOY_PATH"
cd "$DEPLOY_PATH"

# 复制server目录
echo "2. 复制server文件..."
if [ -d "server" ]; then
    echo "   server目录已存在，备份为 server.backup.$(date +%Y%m%d_%H%M%S)"
    mv server "server.backup.$(date +%Y%m%d_%H%M%S)"
fi
cp -r "$SCRIPT_DIR" .

# 进入server目录
cd server

# 检查Python环境
echo "3. 检查Python环境..."
if [ ! -f "/opt/venv/models/bin/activate" ]; then
    echo "错误: 未找到Python虚拟环境 /opt/venv/models/bin/activate"
    echo "请先运行模型环境安装脚本: ./scripts/07_models_setup.sh"
    exit 1
fi

# 安装依赖（需已安装 uv）
echo "4. 安装 Python 依赖..."
if ! command -v uv &> /dev/null; then
    echo "错误: 未找到 uv，请先安装: curl -LsSf https://astral.sh/uv/install.sh | sh"
    exit 1
fi
source /opt/venv/models/bin/activate
uv pip install -r requirements.txt || uv sync --no-dev

# 创建日志目录
echo "5. 创建日志目录..."
mkdir -p /data/logs

# 配置环境变量
echo "6. 配置环境变量..."
if [ ! -f ".env" ]; then
    if [ -f ".env.example" ]; then
        cp .env.example .env
        echo "  已创建.env文件，请编辑配置："
        echo "    vim $DEPLOY_PATH/server/.env"
    fi
else
    echo "  .env文件已存在，跳过创建"
fi

# 更新systemd服务文件
echo "7. 更新systemd服务文件..."
if [ -f "model-server.service" ]; then
    # 替换服务文件中的路径
    sed -i.bak "s|WorkingDirectory=.*|WorkingDirectory=$DEPLOY_PATH|g" model-server.service
    sed -i.bak "s|EnvironmentFile=.*|EnvironmentFile=$DEPLOY_PATH/server/.env|g" model-server.service
    echo "  服务文件已更新"
    echo ""
    echo "  下一步："
    echo "    sudo cp $DEPLOY_PATH/server/model-server.service /etc/systemd/system/"
    echo "    sudo systemctl daemon-reload"
    echo "    sudo systemctl start model-server"
else
    echo "  未找到model-server.service文件"
fi

# 设置权限
echo "8. 设置文件权限..."
chmod +x start.sh install.sh test_api.sh 2>/dev/null || true

echo ""
echo "=========================================="
echo "部署完成！"
echo "=========================================="
echo ""
echo "部署路径: $DEPLOY_PATH/server"
echo ""
echo "下一步："
echo "1. 编辑配置文件:"
echo "   vim $DEPLOY_PATH/server/.env"
echo ""
echo "2. 启动服务："
echo "   方式A - 直接启动:"
echo "     cd $DEPLOY_PATH/server && ./start.sh"
echo ""
echo "   方式B - 使用systemd:"
echo "     sudo cp $DEPLOY_PATH/server/model-server.service /etc/systemd/system/"
echo "     sudo systemctl daemon-reload"
echo "     sudo systemctl start model-server"
echo "     sudo systemctl enable model-server"
echo ""
echo "3. 测试API:"
echo "     cd $DEPLOY_PATH/server && ./test_api.sh"
echo ""
