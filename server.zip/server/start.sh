#!/bin/bash
# 模型服务器启动脚本

set -e

# 获取脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# 判断是在server目录还是项目根目录
if [ -f "$SCRIPT_DIR/main.py" ]; then
    # 在server目录中
    WORK_DIR="$SCRIPT_DIR"
elif [ -f "$SCRIPT_DIR/server/main.py" ]; then
    # 在项目根目录中
    WORK_DIR="$SCRIPT_DIR"
else
    echo "错误: 无法找到server目录"
    exit 1
fi

cd "$WORK_DIR"

# 激活Python环境
if [ -f "/opt/venv/models/bin/activate" ]; then
    source /opt/venv/models/bin/activate
else
    echo "警告: 未找到Python虚拟环境 /opt/venv/models/bin/activate"
    echo "请确保已安装Python环境"
fi

# 检查.env文件
if [ ! -f ".env" ]; then
    echo "警告: 未找到.env配置文件，使用默认配置"
    if [ -f ".env.example" ]; then
        echo "提示: 可以复制 .env.example 到 .env 并修改配置"
    fi
fi

# 创建日志目录
mkdir -p /data/logs

# 启动服务
echo "正在启动模型API服务器..."
echo "工作目录: $WORK_DIR"

# 判断运行方式
if [ -f "$WORK_DIR/main.py" ]; then
    # 在server目录中，直接运行
    python -m server.main
elif [ -f "$WORK_DIR/server/main.py" ]; then
    # 在项目根目录中
    python -m server.main
else
    echo "错误: 无法找到main.py文件"
    exit 1
fi
