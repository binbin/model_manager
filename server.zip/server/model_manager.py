"""
模型管理器 - 支持多模型加载和管理
"""
import os
import logging
import asyncio
from typing import Any, AsyncGenerator, Dict, List, Optional, Tuple
from pathlib import Path

import torch
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    Qwen3VLForConditionalGeneration,
    AutoProcessor
)
from sentence_transformers import SentenceTransformer

from server.config import Settings

logger = logging.getLogger(__name__)


def _embedding_has_safetensors(model_path: str) -> bool:
    """检查嵌入模型目录是否包含 safetensors 权重（避免 torch.load / PyTorch>=2.6 要求）"""
    path = Path(model_path)
    if not path.is_dir():
        return False
    if (path / "model.safetensors").is_file():
        return True
    return (path / "model.safetensors.index.json").is_file()


class ModelManager:
    """模型管理器，支持多模型加载和管理"""
    
    def __init__(self, settings: Settings):
        self.settings = settings
        self.models: Dict[str, Dict[str, Any]] = {}
        self.model_configs = settings.models
        
    async def initialize(self):
        """初始化并加载所有配置的模型"""
        logger.info("开始初始化模型...")
        
        for model_id, config in self.model_configs.items():
            if config.get("enabled", True):
                try:
                    await self.load_model(model_id, config)
                except Exception as e:
                    logger.error(f"加载模型 {model_id} 失败: {e}", exc_info=True)
                    if config.get("required", False):
                        raise
        
        logger.info(f"模型初始化完成，已加载 {len(self.models)} 个模型")
    
    async def load_model(self, model_id: str, config: Dict[str, Any]):
        """加载单个模型"""
        model_path = config["path"]
        model_type = config.get("type", "causal_lm")
        
        logger.info(f"正在加载模型 {model_id} ({model_type}) from {model_path}")
        
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"模型路径不存在: {model_path}")
        
        model_info = {
            "id": model_id,
            "type": model_type,
            "path": model_path,
            "config": config
        }
        
        try:
            if model_type == "causal_lm":
                # 标准因果语言模型（如Qwen3-A3B）
                tokenizer = AutoTokenizer.from_pretrained(
                    model_path,
                    trust_remote_code=True
                )
                model = AutoModelForCausalLM.from_pretrained(
                    model_path,
                    torch_dtype=torch.bfloat16,
                    device_map="auto",
                    trust_remote_code=True,
                    low_cpu_mem_usage=True
                )
                model.eval()
                model_info["model"] = model
                model_info["tokenizer"] = tokenizer
                
            elif model_type == "vision_lm":
                # 视觉语言模型（如 Qwen3-VL）：有 safetensors 则优先，否则用 .bin（需 PyTorch>=2.6）
                processor = AutoProcessor.from_pretrained(
                    model_path,
                    trust_remote_code=True
                )
                has_safetensors = _embedding_has_safetensors(model_path)
                model = Qwen3VLForConditionalGeneration.from_pretrained(
                    model_path,
                    dtype="auto",
                    device_map="auto",
                    trust_remote_code=True,
                    use_safetensors=has_safetensors,
                )
                model.eval()
                model_info["model"] = model
                model_info["processor"] = processor
                
            elif model_type == "embedding":
                # 嵌入模型（如 BGE）：有 safetensors 则优先，否则用 .bin（需 PyTorch>=2.6）
                has_safetensors = _embedding_has_safetensors(model_path)
                if has_safetensors:
                    model = SentenceTransformer(
                        model_path, model_kwargs={"use_safetensors": True}
                    )
                else:
                    model = SentenceTransformer(
                        model_path, model_kwargs={"use_safetensors": False}
                    )
                model_info["model"] = model

            elif model_type == "asr":
                from qwen_asr import Qwen3ASRModel

                dtype = torch.bfloat16 if hasattr(torch, "bfloat16") else torch.float16
                model = Qwen3ASRModel.from_pretrained(
                    model_path,
                    dtype=dtype,
                    device_map="auto",
                    max_inference_batch_size=8,
                    max_new_tokens=512,
                )
                model.eval()
                model_info["model"] = model

            elif model_type == "tts":
                from qwen_tts import Qwen3TTSModel

                dtype = torch.bfloat16 if hasattr(torch, "bfloat16") else torch.float16
                model = Qwen3TTSModel.from_pretrained(
                    model_path,
                    device_map="auto",
                    dtype=dtype,
                )
                model_info["model"] = model

            else:
                raise ValueError(f"不支持的模型类型: {model_type}")
            
            self.models[model_id] = model_info
            logger.info(f"模型 {model_id} 加载成功")
            
        except Exception as e:
            logger.error(f"加载模型 {model_id} 时出错: {e}", exc_info=True)
            raise
    
    async def has_model(self, model_id: str) -> bool:
        """检查模型是否已加载"""
        return model_id in self.models
    
    async def list_models(self) -> List[str]:
        """列出所有已加载的模型ID"""
        return list(self.models.keys())
    
    async def get_models_status(self) -> Dict[str, Any]:
        """获取所有模型的状态"""
        status = {}
        for model_id, model_info in self.models.items():
            status[model_id] = {
                "loaded": True,
                "type": model_info["type"],
                "path": model_info["path"]
            }
        return status
    
    async def generate(
        self,
        model_id: str,
        messages: List[Dict[str, str]],
        temperature: float = 0.7,
        max_tokens: int = 2048,
        top_p: float = 0.9,
        top_k: int = 50,
        frequency_penalty: float = 0.0,
        presence_penalty: float = 0.0,
        stop: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """生成文本（非流式）"""
        if model_id not in self.models:
            raise ValueError(f"模型 {model_id} 未加载")
        
        model_info = self.models[model_id]
        model_type = model_info["type"]
        
        if model_type == "causal_lm":
            return await self._generate_causal_lm(
                model_info, messages, temperature, max_tokens,
                top_p, top_k, frequency_penalty, presence_penalty, stop
            )
        elif model_type == "vision_lm":
            return await self._generate_vision_lm(
                model_info, messages, temperature, max_tokens,
                top_p, top_k, frequency_penalty, presence_penalty, stop
            )
        else:
            raise ValueError(f"模型类型 {model_type} 不支持文本生成")
    
    async def _generate_causal_lm(
        self,
        model_info: Dict[str, Any],
        messages: List[Dict[str, str]],
        temperature: float,
        max_tokens: int,
        top_p: float,
        top_k: int,
        frequency_penalty: float,
        presence_penalty: float,
        stop: Optional[List[str]]
    ) -> Dict[str, Any]:
        """因果语言模型生成"""
        model = model_info["model"]
        tokenizer = model_info["tokenizer"]
        
        # 在线程池中执行，避免阻塞事件循环
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(
            None,
            self._generate_causal_lm_sync,
            model, tokenizer, messages, temperature, max_tokens,
            top_p, top_k, frequency_penalty, presence_penalty, stop
        )
        return result
    
    def _generate_causal_lm_sync(
        self,
        model,
        tokenizer,
        messages: List[Dict[str, str]],
        temperature: float,
        max_tokens: int,
        top_p: float,
        top_k: int,
        frequency_penalty: float,
        presence_penalty: float,
        stop: Optional[List[str]]
    ) -> Dict[str, Any]:
        """同步生成（在线程池中执行）"""
        # 应用chat template
        text = tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True
        )
        
        # Tokenize
        model_inputs = tokenizer([text], return_tensors="pt").to(model.device)
        
        # 生成参数
        generation_kwargs = {
            "max_new_tokens": max_tokens,
            "temperature": temperature if temperature > 0 else None,
            "top_p": top_p if temperature > 0 else None,
            "top_k": top_k if temperature > 0 else None,
            "do_sample": temperature > 0,
        }
        
        if stop:
            generation_kwargs["stop_strings"] = stop
        
        # 生成
        with torch.no_grad():
            generated_ids = model.generate(
                **model_inputs,
                **{k: v for k, v in generation_kwargs.items() if v is not None}
            )
        
        # 解码输出
        output_ids = generated_ids[0][len(model_inputs.input_ids[0]):].tolist()
        content = tokenizer.decode(output_ids, skip_special_tokens=True)
        
        # 计算token数量
        prompt_tokens = len(model_inputs.input_ids[0])
        completion_tokens = len(output_ids)
        
        return {
            "content": content,
            "finish_reason": "stop",
            "usage": {
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "total_tokens": prompt_tokens + completion_tokens
            }
        }
    
    async def _generate_vision_lm(
        self,
        model_info: Dict[str, Any],
        messages: List[Dict[str, str]],
        temperature: float,
        max_tokens: int,
        top_p: float,
        top_k: int,
        frequency_penalty: float,
        presence_penalty: float,
        stop: Optional[List[str]]
    ) -> Dict[str, Any]:
        """视觉语言模型生成"""
        model = model_info["model"]
        processor = model_info["processor"]
        
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(
            None,
            self._generate_vision_lm_sync,
            model, processor, messages, temperature, max_tokens,
            top_p, top_k, frequency_penalty, presence_penalty, stop
        )
        return result
    
    def _generate_vision_lm_sync(
        self,
        model,
        processor,
        messages: List[Dict[str, str]],
        temperature: float,
        max_tokens: int,
        top_p: float,
        top_k: int,
        frequency_penalty: float,
        presence_penalty: float,
        stop: Optional[List[str]]
    ) -> Dict[str, Any]:
        """视觉语言模型同步生成"""
        # 处理输入
        inputs = processor.apply_chat_template(
            messages,
            tokenize=True,
            add_generation_prompt=True,
            return_dict=True,
            return_tensors="pt"
        )
        inputs = inputs.to(model.device)
        
        # 生成参数
        generation_kwargs = {
            "max_new_tokens": max_tokens,
            "temperature": temperature if temperature > 0 else None,
            "top_p": top_p if temperature > 0 else None,
            "do_sample": temperature > 0,
        }
        
        # 生成
        with torch.no_grad():
            generated_ids = model.generate(
                **inputs,
                **{k: v for k, v in generation_kwargs.items() if v is not None}
            )
        
        # 解码输出
        generated_ids_trimmed = [
            out_ids[len(in_ids):] for in_ids, out_ids in zip(inputs.input_ids, generated_ids)
        ]
        output_text = processor.batch_decode(
            generated_ids_trimmed,
            skip_special_tokens=True,
            clean_up_tokenization_spaces=False
        )
        
        content = output_text[0] if output_text else ""
        prompt_tokens = inputs.input_ids.shape[1]
        completion_tokens = len(generated_ids_trimmed[0])
        
        return {
            "content": content,
            "finish_reason": "stop",
            "usage": {
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "total_tokens": prompt_tokens + completion_tokens
            }
        }
    
    async def generate_stream(
        self,
        model_id: str,
        messages: List[Dict[str, str]],
        temperature: float = 0.7,
        max_tokens: int = 2048,
        top_p: float = 0.9,
        top_k: int = 50,
        frequency_penalty: float = 0.0,
        presence_penalty: float = 0.0,
        stop: Optional[List[str]] = None
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """流式生成文本"""
        if model_id not in self.models:
            raise ValueError(f"模型 {model_id} 未加载")
        
        model_info = self.models[model_id]
        model_type = model_info["type"]
        
        if model_type == "causal_lm":
            async for chunk in self._generate_causal_lm_stream(
                model_info, messages, temperature, max_tokens,
                top_p, top_k, frequency_penalty, presence_penalty, stop
            ):
                yield chunk
        elif model_type == "vision_lm":
            async for chunk in self._generate_vision_lm_stream(
                model_info, messages, temperature, max_tokens,
                top_p, top_k, frequency_penalty, presence_penalty, stop
            ):
                yield chunk
        else:
            raise ValueError(f"模型类型 {model_type} 不支持流式生成")
    
    async def _generate_causal_lm_stream(
        self,
        model_info: Dict[str, Any],
        messages: List[Dict[str, str]],
        temperature: float,
        max_tokens: int,
        top_p: float,
        top_k: int,
        frequency_penalty: float,
        presence_penalty: float,
        stop: Optional[List[str]]
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """因果语言模型流式生成"""
        model = model_info["model"]
        tokenizer = model_info["tokenizer"]
        
        # 应用chat template
        text = tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True
        )
        
        # Tokenize
        model_inputs = tokenizer([text], return_tensors="pt").to(model.device)
        
        # 生成参数
        generation_kwargs = {
            "max_new_tokens": max_tokens,
            "temperature": temperature if temperature > 0 else None,
            "top_p": top_p if temperature > 0 else None,
            "top_k": top_k if temperature > 0 else None,
            "do_sample": temperature > 0,
        }
        
        # 简化版流式生成：分批生成并逐token输出
        # 注意：这是简化实现，实际应该使用transformers的streamer
        loop = asyncio.get_event_loop()
        
        def generate_sync():
            with torch.no_grad():
                return model.generate(
                    **model_inputs,
                    **{k: v for k, v in generation_kwargs.items() if v is not None}
                )
        
        generated_ids = await loop.run_in_executor(None, generate_sync)
        
        # 解码并逐token输出
        output_ids = generated_ids[0][len(model_inputs.input_ids[0]):].tolist()
        
        # 逐token解码并输出
        for i in range(len(output_ids)):
            token_ids = output_ids[:i+1]
            content = tokenizer.decode(token_ids, skip_special_tokens=True)
            
            # 只输出新增的部分
            if i > 0:
                prev_content = tokenizer.decode(output_ids[:i], skip_special_tokens=True)
                new_content = content[len(prev_content):]
            else:
                new_content = content
            
            if new_content:
                yield {
                    "content": new_content,
                    "finish_reason": None
                }
        
        # 发送结束标记
        yield {
            "content": "",
            "finish_reason": "stop"
        }
    
    async def _generate_vision_lm_stream(
        self,
        model_info: Dict[str, Any],
        messages: List[Dict[str, str]],
        temperature: float,
        max_tokens: int,
        top_p: float,
        top_k: int,
        frequency_penalty: float,
        presence_penalty: float,
        stop: Optional[List[str]]
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """视觉语言模型流式生成（简化版）"""
        # 视觉模型流式生成较复杂，这里使用非流式生成然后模拟流式输出
        result = await self._generate_vision_lm(
            model_info, messages, temperature, max_tokens,
            top_p, top_k, frequency_penalty, presence_penalty, stop
        )
        
        # 逐字符输出（简化实现）
        content = result["content"]
        for char in content:
            yield {
                "content": char,
                "finish_reason": None
            }
        
        yield {
            "content": "",
            "finish_reason": "stop"
        }
    
    async def generate_embeddings(
        self,
        model_id: str,
        texts: List[str]
    ) -> Dict[str, Any]:
        """生成嵌入向量"""
        if model_id not in self.models:
            raise ValueError(f"模型 {model_id} 未加载")
        
        model_info = self.models[model_id]
        model_type = model_info["type"]
        
        if model_type != "embedding":
            raise ValueError(f"模型 {model_id} 不是嵌入模型")
        
        model = model_info["model"]
        
        # 在线程池中执行
        loop = asyncio.get_event_loop()
        embeddings = await loop.run_in_executor(
            None,
            lambda: model.encode(texts, normalize_embeddings=True)
        )
        
        # 估算token数量（简化处理）
        total_tokens = sum(len(text.split()) * 1.3 for text in texts)  # 粗略估算
        
        return {
            "embeddings": embeddings,
            "prompt_tokens": int(total_tokens),
            "total_tokens": int(total_tokens)
        }

    async def transcribe(
        self,
        model_id: str,
        audio: str,
        language: Optional[str] = None,
    ) -> Dict[str, Any]:
        """语音识别：音频转文字。audio 为本地文件路径或 URL。"""
        if model_id not in self.models:
            raise ValueError(f"模型 {model_id} 未加载")
        model_info = self.models[model_id]
        if model_info["type"] != "asr":
            raise ValueError(f"模型 {model_id} 不是 ASR 模型")
        model = model_info["model"]

        def _transcribe_sync() -> Dict[str, Any]:
            results = model.transcribe(audio=audio, language=language)
            if not results:
                return {"text": "", "language": None}
            first = results[0]
            text = getattr(first, "text", "") or ""
            lang = getattr(first, "language", None)
            return {"text": text, "language": lang}

        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, _transcribe_sync)

    async def tts_generate(
        self,
        model_id: str,
        text: str,
        language: str = "Chinese",
        speaker: str = "Vivian",
        instruct: str = "",
    ) -> Tuple[bytes, int]:
        """文本转语音：返回 (wav_bytes, sample_rate)。"""
        if model_id not in self.models:
            raise ValueError(f"模型 {model_id} 未加载")
        model_info = self.models[model_id]
        if model_info["type"] != "tts":
            raise ValueError(f"模型 {model_id} 不是 TTS 模型")
        model = model_info["model"]

        def _tts_sync() -> Tuple[bytes, int]:
            import io
            import soundfile as sf

            wavs, sr = model.generate_custom_voice(
                text=text,
                language=language,
                speaker=speaker,
                instruct=instruct,
            )
            if not wavs or sr <= 0:
                raise ValueError("TTS 未返回有效音频")
            buf = io.BytesIO()
            sf.write(buf, wavs[0], sr, format="WAV")
            return buf.getvalue(), sr

        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, _tts_sync)

    async def cleanup(self):
        """清理资源"""
        logger.info("正在清理模型资源...")
        for model_id, model_info in self.models.items():
            try:
                if "model" in model_info:
                    del model_info["model"]
                if "tokenizer" in model_info:
                    del model_info["tokenizer"]
                if "processor" in model_info:
                    del model_info["processor"]
                logger.info(f"已清理模型 {model_id}")
            except Exception as e:
                logger.error(f"清理模型 {model_id} 时出错: {e}")
        
        # 清理GPU缓存
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        
        self.models.clear()
        logger.info("模型资源清理完成")
