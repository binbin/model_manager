"""
配置文件管理
"""
import os
from typing import List, Dict, Any
from functools import lru_cache

try:
    from pydantic_settings import BaseSettings
    from pydantic import Field
except ImportError:
    # 兼容旧版本pydantic
    from pydantic import BaseSettings, Field


class Settings(BaseSettings):
    """应用配置"""
    
    # 服务配置
    host: str = Field(default="0.0.0.0", env="HOST")
    port: int = Field(default=8000, env="PORT")
    log_level: str = Field(default="INFO", env="LOG_LEVEL")
    
    # API密钥配置（多个密钥用逗号分隔）
    api_keys: List[str] = Field(default_factory=list, env="API_KEYS")
    
    # CORS配置
    cors_origins: List[str] = Field(
        default_factory=lambda: ["*"],
        env="CORS_ORIGINS"
    )
    
    # 模型配置
    models: Dict[str, Dict[str, Any]] = Field(default_factory=dict)
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        # 处理API密钥
        if isinstance(self.api_keys, str):
            self.api_keys = [k.strip() for k in self.api_keys.split(",") if k.strip()]
        
        # 处理CORS origins
        if isinstance(self.cors_origins, str):
            self.cors_origins = [o.strip() for o in self.cors_origins.split(",") if o.strip()]
        
        # 加载模型配置
        if not self.models:
            self.models = self._load_default_models()
    
    def _load_default_models(self) -> Dict[str, Dict[str, Any]]:
        """加载默认模型配置"""
        models = {}
        
        # Qwen3-A3B模型（必选）
        qwen3_a3b_path = os.getenv("QWEN3_A3B_PATH", "/data/models/qwen3-a3b")
        if os.path.exists(qwen3_a3b_path):
            models["qwen3-a3b"] = {
                "path": qwen3_a3b_path,
                "type": "causal_lm",
                "enabled": True,
                "required": True
            }
        
        # Qwen3-VL模型（可选）
        qwen3_vl_path = os.getenv("QWEN3_VL_PATH", "/data/models/qwen3-vl")
        if os.path.exists(qwen3_vl_path):
            models["qwen3-vl"] = {
                "path": qwen3_vl_path,
                "type": "vision_lm",
                "enabled": os.getenv("QWEN3_VL_ENABLED", "false").lower() == "true",
                "required": False
            }
        
        # BGE嵌入模型（可选）
        bge_path = os.getenv("BGE_PATH", "/data/models/bge")
        if os.path.exists(bge_path):
            models["bge-large-zh-v1.5"] = {
                "path": bge_path,
                "type": "embedding",
                "enabled": os.getenv("BGE_ENABLED", "false").lower() == "true",
                "required": False
            }
        
        # Qwen3-ASR 语音识别模型（可选）
        qwen3_asr_path = os.getenv("QWEN3_ASR_PATH", "/data/models/qwen3-asr")
        if os.path.exists(qwen3_asr_path):
            models["qwen3-asr"] = {
                "path": qwen3_asr_path,
                "type": "asr",
                "enabled": os.getenv("QWEN3_ASR_ENABLED", "false").lower() == "true",
                "required": False
            }
        
        # Qwen3-TTS模型（可选）
        qwen3_tts_path = os.getenv("QWEN3_TTS_PATH", "/data/models/qwen3-tts")
        if os.path.exists(qwen3_tts_path):
            models["qwen3-tts"] = {
                "path": qwen3_tts_path,
                "type": "tts",
                "enabled": os.getenv("QWEN3_TTS_ENABLED", "false").lower() == "true",
                "required": False
            }
        
        return models


@lru_cache()
def get_settings() -> Settings:
    """获取配置实例（单例）"""
    return Settings()
